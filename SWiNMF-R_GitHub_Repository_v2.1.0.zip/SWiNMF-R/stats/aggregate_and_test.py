#!/usr/bin/env python3
"""Seed-aligned per-dataset/method descriptive aggregation and exploratory Holm-adjusted Wilcoxon.
Seeds reflect random initialization, NOT independent image datasets. Inference is conditional.
"""
import argparse,json,math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import t,wilcoxon,friedmanchisquare
MET=('ACC','NMI','ARI','macroF1')
def summarize(logroot,outdir):
    allrows=[]
    for p in Path(logroot).rglob('*.json'):
        if 'provenance' in p.name or 'summary' in p.parts or 'environment' in p.name:continue
        try:row=json.loads(p.read_text())
        except (ValueError,OSError):continue
        if not isinstance(row,dict) or not {'dataset','method','seed',*MET}.issubset(row):continue
        if 'parameter' in row or str(row.get('method','')).endswith('/sensitivity'):continue  # separate descriptive sweep, never pool as standard seeds
        allrows.append(row)
    if not allrows:raise ValueError('No measured run JSON files found')
    for r in allrows:
        for key in MET:
            if not isinstance(r[key],(float,int)) or not np.isfinite(r[key]):raise ValueError('Invalid metric in '+str(r))
    df=pd.json_normalize(allrows,sep='_');df['seed']=df['seed'].astype(int)
    if df.duplicated(['dataset','method','seed']).any():raise ValueError('Duplicate dataset+method+seed run; reject rather than double-count')
    out=Path(outdir);out.mkdir(parents=True,exist_ok=True)
    cols=['dataset','method','seed',*MET]
    df.to_csv(out/'all_seed_results.csv',index=False)
    report=[]
    for (ds,method),g in df.groupby(['dataset','method']):
        r={'dataset':ds,'method':method,'seeds':','.join(map(str,sorted(g.seed)))}
        for key in MET:
            vals=g[key].to_numpy(float);n=len(vals);mean=float(np.mean(vals));sd=float(np.std(vals,ddof=1)) if n>1 else float('nan')
            half=float(t.ppf(.975,n-1)*sd/math.sqrt(n)) if n>1 else float('nan')
            r[key+'_n']=n;r[key+'_mean']=mean;r[key+'_sd']=sd;r[key+'_ci95_low']=mean-half;r[key+'_ci95_high']=mean+half
        report.append(r)
    pd.DataFrame(report).to_csv(out/'mean_sd_ci_by_dataset_method.csv',index=False)
    tested=[]
    for (ds,metric),g in [( (ds,met),sub) for ds,sub in df.groupby('dataset') for met in MET]:
        target=g[g.method=='SWiNMF-R/full'].set_index('seed')[metric] if 'SWiNMF-R/full' in set(g.method) else None
        if target is None:continue
        testblock=[]
        for m in sorted(set(g.method)-{'SWiNMF-R/full'}):
            sub=g[g.method==m].set_index('seed')[metric]
            aligned=target.to_frame('a').join(sub.to_frame('b'),how='inner').dropna()
            if len(aligned)<5:continue
            delta=(aligned.a-aligned.b).to_numpy(float)
            if np.all(delta==0):stat,p=0.,1.
            else:stat,p=wilcoxon(delta,zero_method='wilcox',alternative='two-sided')
            testblock.append({'dataset':ds,'metric':metric,'comparator':m,
                              'matched_seeds':','.join(map(str,aligned.index.tolist())),
                              'n_pairs':len(aligned),'mean_delta':float(np.mean(delta)),
                              'statistic':float(stat),'p_raw':float(p),
                              'scope':'exploratory paired-seed initialization sensitivity; not population-level significance'})
        # Holm correction within dataset x metric across baseline comparisons.
        n=len(testblock);order=sorted(range(n),key=lambda i:testblock[i]['p_raw']);largest=0
        for rank,i in enumerate(order):
            largest=max(largest, min(1.,(n-rank)*testblock[i]['p_raw']))
            testblock[i]['p_holm']=largest
        tested.extend(testblock)
    pd.DataFrame(tested,columns=['dataset','metric','comparator','matched_seeds','n_pairs','mean_delta','statistic','p_raw','p_holm','scope']).to_csv(out/'paired_seed_exploratory.csv',index=False)
    (out/'INTERPRETATION.txt').write_text('These 95% intervals and Wilcoxon tests quantify variability across random initializations on fixed benchmarks; they do not establish independent-population generalizability. Never tune using held-out labels.\n')
    return len(df),len(report),len(tested)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--logs',default='logs');p.add_argument('--outdir',default='stats/out');a=p.parse_args();print('Counts',summarize(a.logs,a.outdir))

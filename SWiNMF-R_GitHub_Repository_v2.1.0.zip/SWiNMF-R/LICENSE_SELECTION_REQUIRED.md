# Software license selection required before public release

The author has not specified copyright ownership or a software license. We have
**not** invented a permission grant on their behalf. By default, publicly hosting
source code on GitHub does not automatically grant all third parties permission
to modify or redistribute it.

The copyright holder should select an appropriate license (e.g., MIT, Apache-2.0,
BSD-3-Clause, GPL-3.0) with regard to ownership, employment agreements and any
included third-party code. Then commit the exact license text as `LICENSE` and
update the GitHub release metadata. This source-only repository does not include
or relicense any third-party image datasets, model weights or results.

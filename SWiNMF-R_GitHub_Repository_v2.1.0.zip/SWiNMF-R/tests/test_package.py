import csv,json,tempfile,unittest
from pathlib import Path
import numpy as np
from scipy import sparse
from swinmf.model import Config,check_X,normalize,split,graph,terms,gradients,optimize,metrics,parse_seeds,run_dataset
from baselines.matched_baselines import custom_nmf,run_baselines
from stats.aggregate_and_test import summarize
class TestRelease(unittest.TestCase):
 def setUp(self):
  self.rng=np.random.default_rng(42);self.X=self.rng.random((12,24));self.cfg=Config(kg=4,max_iter=15,eta=.004)
 def test_graph_psd(self):
  S,D,L=graph(normalize(self.X),4);self.assertAlmostEqual(float(sparse.linalg.norm(S-S.T)),0,places=11)
  self.assertLess(np.max(np.abs(L@np.ones(24))),1e-9)
  self.assertGreater(np.linalg.eigvalsh(L.toarray()).min(),-1e-9)
  self.assertEqual(np.count_nonzero(S.diagonal()),0)
 def test_duplicate_and_zeros(self):
  X=normalize(self.X.copy());X[:,0]=0;X[:,1]=X[:,2]
  S,D,L=graph(X,3);self.assertTrue(np.all(np.isfinite(L.data)))
 def test_objective_gradient_finite_difference(self):
  X=normalize(self.X);X1,X2,_=split(X,.5);S,D,L=graph(X,4)
  W1=self.rng.random((6,3));W2=self.rng.random((6,3));H=self.rng.random((3,24));lam=.8;s1=(X1*X1).sum();s2=(X2*X2).sum()
  gs=gradients(X1,X2,W1,W2,H,lam,L,self.cfg,s1,s2)
  def fun(l):return terms(X1,X2,W1,W2,H,l,L,self.cfg,s1,s2)['objective']
  eps=1e-6
  for ar,g in zip([W1,W2,H],gs[:3]):
   for i,j in [(0,0),(-1,-1)]:
    old=ar[i,j];ar[i,j]=old+eps;plus=fun(lam);ar[i,j]=old-eps;minus=fun(lam);ar[i,j]=old
    self.assertAlmostEqual((plus-minus)/(2*eps),g[i,j],places=5)
  self.assertAlmostEqual((fun(lam+eps)-fun(lam-eps))/(2*eps),gs[3],places=5)
 def test_trace_descent_and_feasibility(self):
  for variant in ['full','graph_off','lambda_fixed','complement_off']:
   q=optimize(self.X,3,self.cfg,variant=variant)
   self.assertTrue(all(np.isfinite(z['objective']) for z in q['trace']))
   self.assertTrue(np.all(np.diff([z['objective'] for z in q['trace']])<1e-8))
   self.assertGreaterEqual(q['W1'].min(),0);self.assertGreaterEqual(q['W2'].min(),0);self.assertGreaterEqual(q['H'].min(),0)
   self.assertEqual(q['trace'][0]['iteration'],0)
   if variant=='complement_off':self.assertEqual(q['lambda'],0)
   elif variant=='lambda_fixed':self.assertEqual(q['lambda'],self.cfg.lambda0)
   else:self.assertTrue(self.cfg.lambda_min<=q['lambda']<=self.cfg.lambda_max)
 def test_reproducibility(self):
  a=optimize(self.X,3,self.cfg,seed=66);b=optimize(self.X,3,self.cfg,seed=66)
  self.assertTrue(np.array_equal(a['W1'],b['W1']));self.assertTrue(np.array_equal(a['H'],b['H']))
 def test_lambda_bound_activation(self):
  self.assertAlmostEqual(np.clip(1-1.8/2,.1,1),.1)
  self.assertEqual(np.clip(1-100/2,.1,1),.1)
 def test_noncontiguous_class_labels(self):
  res=metrics(np.array([12,12,1001,1001,87,87]),np.array([99,99,-8,-8,17,17]))
  self.assertAlmostEqual(res['ACC'],1);self.assertAlmostEqual(res['macroF1'],1)
 def test_param_validation(self):
  with self.assertRaises(ValueError):check_X(-self.X,3)
  with self.assertRaises(ValueError):optimize(self.X,3,Config(kg=24))
  with self.assertRaises(ValueError):optimize(self.X,3,Config(lambda_min=1.1))
  with self.assertRaises(ValueError):parse_seeds('0,0')
 def test_baseline_dimensions_nonnegative(self):
  X=normalize(self.X)
  for name in ('GNMF','SparseNMF','FeatureWeightedNMF'):
   H,it,val=custom_nmf(X,3,method=name,kg=4,T=5)
   self.assertEqual(H.shape,(3,24));self.assertTrue(np.isfinite(val));self.assertGreaterEqual(H.min(),0)
 def test_real_logs_generated_for_synthetic(self):
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'synthetic.npz';np.savez(path,X=self.X,y=np.repeat([10,50,70],8))
   rows=run_dataset(path,'synthetic_only',Path(tmp)/'runs',[0,1],Config(kg=4,max_iter=8),('full',))
   run_baselines(path,'synthetic_only',Path(tmp)/'runs',[0,1],methods=('NMF',),max_iter=8)
   self.assertEqual(len(rows),2);self.assertTrue(Path(tmp,'runs','synthetic_only__SWiNMF-R-full__seed_00_trace.csv').exists())
   with (Path(tmp)/'runs'/'synthetic_only__SWiNMF-R-full__seed_00_trace.csv').open() as f:
    self.assertEqual(next(csv.DictReader(f))['iteration'],'0')
   count=summarize(Path(tmp)/'runs',Path(tmp)/'stats')
   self.assertEqual(count,(4,2,0))
 def test_seed_alignment_in_statistics(self):
  with tempfile.TemporaryDirectory() as tmp:
   rng=Path(tmp)/'runs';rng.mkdir()
   for m,seeds in [('SWiNMF-R/full',[0,1,2,3,4,5]),('NMF',[5,2,0,1,3,6])]:
    for s in seeds:
     val=.5+s*.01+(m=='SWiNMF-R/full')*.04
     row={'dataset':'toy','method':m,'seed':s,'ACC':val,'NMI':val,'ARI':val,'macroF1':val}
     (rng/f'{m.replace("/","_")}_{s}.json').write_text(json.dumps(row))
   rows=summarize(rng,Path(tmp)/'out');self.assertEqual(rows[2],4)
   import pandas as pd
   tests=pd.read_csv(Path(tmp)/'out'/'paired_seed_exploratory.csv');self.assertEqual(tests.iloc[0]['n_pairs'],5)
   self.assertAlmostEqual(tests.iloc[0]['mean_delta'],.04,places=10)
if __name__=='__main__':unittest.main()

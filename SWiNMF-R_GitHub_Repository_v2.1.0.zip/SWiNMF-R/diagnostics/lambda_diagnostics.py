#!/usr/bin/env python3
"""Analyze real run coefficient paths and bound saturation, excluding initial lambda0."""
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--logs',default='logs');p.add_argument('--outdir',default='figures');a=p.parse_args()
 out=Path(a.outdir);out.mkdir(parents=True,exist_ok=True);dsmap={}
 for path in Path(a.logs).rglob('*_trace.csv'):
  if 'SWiNMF-R-full' in path.name:dsmap.setdefault(path.name.split('__')[0],[]).append(path)
 summary=[]
 for ds,files in sorted(dsmap.items()):
  fig,ax=plt.subplots(figsize=(6,4));final=[];low=0;upper=0;allinterior=[]
  for f in sorted(files):
   df=pd.read_csv(f);z=df['lambda_value'].to_numpy(float)[1:] # exclude initial lambda0
   if len(z)==0:continue
   ax.plot(df['iteration'],df['lambda_value'],alpha=.65)
   final.append(z[-1]);low+=int(np.any(z<=.1+1e-8));upper+=int(np.any(z>=1.-1e-8));allinterior.extend(z.tolist())
  ax.set(xlabel='Iteration',ylabel='lambda',title=ds+' measured coefficient trajectories')
  fig.tight_layout();fig.savefig(out/f'{ds}_lambda.pdf');plt.close(fig)
  summary.append({'dataset':ds,'n_seeds':len(final),'final_mean':float(np.mean(final)) if final else None,
                  'final_sample_sd':float(np.std(final,ddof=1)) if len(final)>1 else None,
                  'seeds_ever_lower':low,'seeds_ever_upper_after_first_update':upper,
                  'fraction_interior_updates':float(np.mean((np.array(allinterior)>.1+1e-8)&(np.array(allinterior)<1.-1e-8))) if allinterior else None})
 (out/'lambda_diagnostics.json').write_text(json.dumps(summary,indent=2))
 print('Analyzed',len(dsmap),'measured datasets')

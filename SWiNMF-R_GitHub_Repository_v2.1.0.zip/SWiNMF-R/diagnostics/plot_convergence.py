#!/usr/bin/env python3
"""Plot every available genuine dataset/seed objective trace; no synthetic relabeling."""
import argparse
from pathlib import Path
import pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--logs',default='logs');p.add_argument('--outdir',default='figures');a=p.parse_args()
 files=list(Path(a.logs).rglob('*_trace.csv'));o=Path(a.outdir);o.mkdir(parents=True,exist_ok=True)
 groups={}
 for path in files:
  name=path.name.split('__')[0]
  if 'SWiNMF-R-full' not in path.name:continue
  groups.setdefault(name,[]).append(path)
 for ds,paths in sorted(groups.items()):
  fig,ax=plt.subplots(figsize=(7,4))
  for f in sorted(paths):
   df=pd.read_csv(f);ax.plot(df['iteration'],df['objective'],label=f.stem.split('seed_')[-1])
  ax.set(xlabel='Iteration (0 = initialization)',ylabel='Full regularized objective',title=f'{ds}: measured objective traces')
  if len(paths)<=20:ax.legend(title='seed',ncol=2,fontsize=7)
  fig.tight_layout();fig.savefig(o/f'{ds}_objective.pdf');plt.close(fig)
 print('Generated',len(groups),'dataset-specific measured objective plots')

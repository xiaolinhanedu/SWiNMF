#!/usr/bin/env python3
"""Build raw32 nonnegative arrays from authorized local ORL/Yale/COIL-20 images.
Required input layout: <root>/<dataset>/<class_id>/<image>.
No download, inferred consent, or silent reshuffling; class ids sorted alphabetically.
"""
import argparse,hashlib,json,platform
from pathlib import Path
import numpy as np
from PIL import Image
EXTS={'.pgm','.jpg','.jpeg','.png','.bmp','.tiff'}
def build(raw,out,dataset):
    raw=Path(raw);classes=sorted(x for x in raw.iterdir() if x.is_dir()) if raw.exists() else []
    if not classes:raise ValueError('No class folders found in '+str(raw))
    vec=[];lab=[];sample=[]
    for i,cls in enumerate(classes):
        for f in sorted(cls.rglob('*')):
            if f.is_file() and f.suffix.lower() in EXTS:
                with Image.open(f) as img:
                    img=img.convert('L').resize((32,32),Image.Resampling.BILINEAR)
                    v=np.asarray(img,dtype=np.float64).reshape(1024)/255.0
                if not np.isfinite(v).all():raise ValueError(str(f))
                vec.append(v);lab.append(i);sample.append({'path':str(f.relative_to(raw)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
    if not vec:raise ValueError('No readable images')
    X=np.stack(vec,axis=1)
    X=X/np.maximum(np.linalg.norm(X,axis=0,keepdims=True),1e-12)
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(out,X=X.astype(np.float32),y=np.asarray(lab,dtype=np.int32))
    meta={'dataset':dataset,'kind':'raw32','source_root':str(raw.resolve()),'class_names':[p.name for p in classes],
          'images':sample,'n':len(lab),'d':1024,'npz_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
          'preprocess':'grayscale PIL L; 32x32 bilinear; flatten row-major; scale /255; L2 normalize per image',
          'python':platform.python_version(),'notice':'Check source dataset license and ethics provenance; not supplied by script'}
    out.with_suffix('.provenance.json').write_text(json.dumps(meta,indent=2))
    print('saved',out,'n',len(lab),'d',1024)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True,help='Local root with <dataset>/<class>/<img>')
 p.add_argument('--outdir',default='descriptors');p.add_argument('--datasets',default='orl,yale,coil20')
 a=p.parse_args()
 for ds in a.datasets.split(','):build(Path(a.root)/ds,Path(a.outdir)/(ds+'.npz'),ds)

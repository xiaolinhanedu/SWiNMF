#!/usr/bin/env python3
"""Frozen torchvision ResNet50 V2 GAP descriptors with exact train+test transductive scope.
MNIST: 60000+10000; STL10: 5000 labeled train+8000 test; CIFAR10: 50000+10000.
The first-party dataset APIs may DOWNLOAD images if --download flag is explicitly used.
Use only authorized dataset access. No labels used for descriptor learning.
"""
import argparse,hashlib,json,platform,os
from pathlib import Path
import numpy as np

def build(name,root,out,batch,device,download):
    import torch,torchvision
    from torchvision.models import resnet50,ResNet50_Weights
    from torch.utils.data import DataLoader,ConcatDataset,Dataset
    enum=ResNet50_Weights.IMAGENET1K_V2
    transform=enum.transforms()
    if name=='mnist':
        cls=torchvision.datasets.MNIST;tr=cls(root,train=True,download=download);te=cls(root,train=False,download=download);n_expect=70000
    elif name=='cifar10':
        cls=torchvision.datasets.CIFAR10;tr=cls(root,train=True,download=download);te=cls(root,train=False,download=download);n_expect=60000
    elif name=='stl10':
        cls=torchvision.datasets.STL10;tr=cls(root,split='train',download=download);te=cls(root,split='test',download=download);n_expect=13000
    else:raise ValueError(name)
    if len(tr)+len(te)!=n_expect:raise ValueError(f'unexpected number of labeled images for {name}')
    class Prepared(Dataset):
        def __init__(self,raw):self.raw=raw
        def __len__(self):return len(self.raw)
        def __getitem__(self,i):
            im,label=self.raw[i]
            return transform(im.convert('RGB')),int(label)
    ds=ConcatDataset([Prepared(tr),Prepared(te)])
    dl=DataLoader(ds,batch_size=batch,shuffle=False,num_workers=0,pin_memory=device=='cuda')
    model=resnet50(weights=enum);model.fc=torch.nn.Identity();model.eval().to(device)
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    # Array itself consumes ~0.57 GiB for MNIST float32; process in batches, never store all PIL images.
    X=np.empty((2048,n_expect),dtype=np.float32);y=np.empty(n_expect,dtype=np.int32)
    pos=0
    with torch.inference_mode():
        for imgs,labels in dl:
            f=model(imgs.to(device)).cpu().numpy().astype(np.float32)
            f=np.maximum(f,0)
            f=f/np.maximum(np.linalg.norm(f,axis=1,keepdims=True),1e-12)
            q=len(labels);X[:,pos:pos+q]=f.T;y[pos:pos+q]=labels.numpy();pos+=q
    if pos!=n_expect:raise RuntimeError('incomplete descriptor creation')
    np.savez_compressed(out,X=X,y=y)
    meta={'dataset':name,'n':pos,'d':2048,'split':'labeled train then labeled test; transductive concatenation',
          'train_n':len(tr),'test_n':len(te),'excluded':'STL10 unlabeled 100000, if applicable',
          'architecture':'torchvision resnet50; fc Identity -> pooled 2048-d features',
          'weights':'ResNet50_Weights.IMAGENET1K_V2','transform':'weights.transforms() (ImageNet V2 inference transforms)',
          'nonnegative':'clip pooled ReLU output to >=0; per-sample L2 normalization','device':device,
          'torch':torch.__version__,'torchvision':torchvision.__version__,'python':platform.python_version(),
          'npz_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_root':str(Path(root).resolve())}
    out.with_suffix('.provenance.json').write_text(json.dumps(meta,indent=2))
    print('Saved',out,'shape',(2048,pos))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--outdir',default='descriptors')
 p.add_argument('--datasets',default='mnist,stl10,cifar10');p.add_argument('--batch-size',type=int,default=64)
 p.add_argument('--device',choices=['cpu','cuda','auto'],default='auto');p.add_argument('--download',action='store_true')
 a=p.parse_args();import torch
 dev=('cuda' if torch.cuda.is_available() else 'cpu') if a.device=='auto' else a.device
 if dev=='cuda' and not torch.cuda.is_available():raise ValueError('No CUDA GPU available')
 for name in a.datasets.split(','):build(name,a.root,Path(a.outdir)/(name+'.npz'),a.batch_size,dev,a.download)

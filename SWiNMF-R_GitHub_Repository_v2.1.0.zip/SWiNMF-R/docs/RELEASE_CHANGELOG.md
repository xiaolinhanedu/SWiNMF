# SWiNMF-R 2.1.0 (source packaging)

- Packaged validated v2 research solver as importable Python modules.
- Added install metadata, deterministic unit-test CI workflow and source citation metadata.
- Added contributor-facing setup, source provenance, experiment protocol,
  explicit scientific-evidence status and GitHub/Zenodo deposition instructions.
- Excluded datasets, benchmark results, paper files and generated synthetic
  metrics from source repository; retained a clearly named synthetic fixture.
- Retained separate data-preprocessing, baseline, ablation, sensitivity,
  statistical-analysis and graph-diagnostic code.

**Research caveat:** not a rerun of the historical SWiNMF numerical results.
The revised objective and optimizer may yield different clustering outcomes.

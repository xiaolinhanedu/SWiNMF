# Frozen SWiNMF-R experimental protocol (proposed for new reruns)

This is a declared rerun protocol, **not historical evidence** that these
settings produced previously published or submitted numbers.

| Dataset | Images | Features | K | Descriptor | Partition |
|---|---:|---:|---:|---|---|
| ORL | 400 | 1024 | 40 | local source images → 32×32 grayscale | All class images |
| Yale | 165 | 1024 | 15 | local source images → 32×32 grayscale | All class images |
| COIL20 | 1440 | 1024 | 20 | local source images → 32×32 grayscale | All class images |
| MNIST | 70000 | 2048 | 10 | frozen ResNet-50 ImageNet1K_V2 | train+test, transductive |
| STL10 | 13000 | 2048 | 10 | frozen ResNet-50 ImageNet1K_V2 | labeled train+test, transductive |
| CIFAR10 | 60000 | 2048 | 10 | frozen ResNet-50 ImageNet1K_V2 | train+test, transductive |

For ORL/Yale/COIL20, the raw image folder taxonomy and actual source sampling
must match the expected sample count and class count. Source files are not
part of this repository. Researchers are responsible for legal dataset access,
licenses and ethics/consent provenance, especially for face images. The raw
preprocessor writes a SHA-256 checksum for every input image into a provenance
manifest. The ResNet script records versions, exact weight enum, preprocessing,
dataset splits and descriptor SHA-256; it does not claim immutable hashes of
remote downloaded input archives.

All method runs must use identical NPZ files (verified by SHA-256), identical
seeds 0–9 and prespecified rank K; keep full per-run JSON and convergence trace
before filling tables. Feature representation is fixed during clustering.
Defaults are documented in `swinmf/model.py`. All-in-one run scripts are
source tools, not evidence that benchmark runs have actually happened.

Compare baseline definitions as provided in `baselines/matched_baselines.py`.
NMF uses sklearn coordinate descent; GNMF, L1-SparseNMF and fixed feature
weighted NMF use projected gradient with backtracking. These models have
**different explicit objectives and solver budgets**, which must be reported.

Descriptive statistics: ACC, arithmetic NMI, ARI, Hungarian macro-F1;
mean±sample SD across seeds, conditional initialization CI and seed-matched
exploratory Wilcoxon (Holm correction). Do not equate p-values across
initializations with population-level inferential evidence.

Graph regularization ablation = alpha 0; fixed-lambda ablation = lambda 1;
complement-off = lambda 0; scale-fixing ablation = eta 0 (diagnostic only).
Unsplit comparison is the separately run NMF baseline. Sensitivity must be
reported descriptively and not used to select hyperparameters against test
labels. Any approximate neighbor backend changes the implementation protocol.

**Missing evidence:** no authentic six-benchmark seed-level logs, published
implementation equivalence, source dataset hashes, runtime on the intended
hardware, image-corruption or CIFAR-100 transfer evaluations are included.

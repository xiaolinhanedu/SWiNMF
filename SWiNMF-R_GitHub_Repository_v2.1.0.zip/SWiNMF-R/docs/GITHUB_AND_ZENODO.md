# GitHub upload and Zenodo DOI instructions

## Upload this repository to GitHub

1. Unzip `SWiNMF-R_GitHub_Repository.zip`. Open the extracted `SWiNMF-R` folder.
2. Log in to GitHub and create a **new empty repository**, e.g. `SWiNMF-R`.
3. To upload through the browser: open the new repository → **Add file** →
   **Upload files**. Upload the **contents** of the extracted `SWiNMF-R`
   directory, maintaining subdirectories (`swinmf`, `baselines`, etc.).
   Do not upload the ZIP as a single archive: doing so will not make the code
   browsable as source files. GitHub's UI may not retain hidden files during
   some browser selection workflows; verify `.github/workflows/ci.yml`,
   `.gitignore`, and `.gitattributes` are present afterwards.
4. Alternatively, in a terminal from the extracted directory:

```bash
git init
git branch -M main
git add .
git commit -m "Add SWiNMF-R source and reproducibility workflow"
git remote add origin https://github.com/YOUR_USERNAME/SWiNMF-R.git
git push -u origin main
```

**Replace** `YOUR_USERNAME` with the real account and create the repository
first. Do not insert access tokens or credentials in code or commits.
Before making the repository public, review every file for ownership,
third-party rights, dataset licensing, and accidental sensitive information.
Add a real `LICENSE` only after the copyright holder chooses one.

## DOI creation with Zenodo

1. Link a GitHub account to Zenodo and **enable the repository** from
   the Zenodo GitHub integration screen.
2. Return to GitHub → Releases → Draft a new release.
3. Create a tag (e.g. `v2.1.0`) and publish the release **after** enabling
   Zenodo integration.
4. Zenodo ingests the release and displays a **real DOI** after processing.
5. Add that DOI to the manuscript Code Availability section, reviewer response,
   `CITATION.cff` (when appropriate) and release documentation.

Official documentation:
- https://help.zenodo.org/docs/github/enable-repository/
- https://help.zenodo.org/docs/github/archive-software/github-upload/
- https://help.zenodo.org/docs/github/describe-software/zenodo-json/

This repository deliberately has no false DOI or placeholder fake identifier.
Do not tell the editor a DOI exists before the corresponding record is live.

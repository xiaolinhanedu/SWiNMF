# Scientific Reports reviewer evidence checklist

This GitHub release provides the inspectable code needed for additional
experiments, **not an assertion that all requested analyses are already done**.

| Reviewer concern | Source capability | Genuine evidence pending |
|---|---|---|
| Same-X NMF comparisons | `baselines/matched_baselines.py` | Six benchmark reruns; provenance of every comparator |
| Variance/statistics | `stats/aggregate_and_test.py` | Ten seed-level records per method/dataset; report actual SD and paired tests |
| Ablations | `ablations/run_ablations.py` | Six dataset (or justified representative) measured control results |
| Sensitivity | `ablations/run_sensitivity.py` | Parametric sweep outputs and label-free tuning protocol |
| Adaptive coefficient | `diagnostics/lambda_diagnostics.py` | Per-dataset trajectories, lower bound activation frequencies |
| Convergence curves | `diagnostics/plot_convergence.py` | Genuine per-dataset objective traces |
| Reproducibility | `descriptors/`, config and hashes | Source dataset provenance, processing confirmation, software versions |
| Overclaims | Revised manuscript/editor letter | Replace qualitative claims only when new measured results support them |
| Editor code archiving | GitHub source, `CITATION.cff` | Author-selected license, GitHub release, actual Zenodo DOI |

The revised SWiNMF-R objective differs from the submitted formulation: ridge
regularization has been added, updates have changed to projected gradient,
lambda bounds and beta changed, and a normalized graph penalty is used.
Numerical results from the original objective are not evidence for the revised
objective. The repository includes no manufactured benchmark scores.

#!/usr/bin/env python3
"""One-variable-at-a-time sensitivity using VALID Hungarian ACC and NMI/ARI/F1.
Results are DESCRIPTIVE and must not be used to choose parameters with test labels.
"""
import argparse,itertools,json,hashlib,time
from pathlib import Path
from dataclasses import asdict
import numpy as np
from sklearn.cluster import KMeans
from swinmf.model import Config,check_X,optimize,metrics,parse_seeds
GRID={'rho':[.3,.4,.5,.6,.7],'kg':[3,5,7,10,15],'alpha':[0.,.01,.1,.3,1.],
      'beta':[.1,1.,10.],'lambda0':[.5,1.],'eta':[0.,.0001,.001,.01]}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--npz',required=True);p.add_argument('--dataset',required=True)
 p.add_argument('--outdir',default='logs/sensitivity');p.add_argument('--seeds',default='0-2')
 p.add_argument('--max-runs',type=int,default=0);p.add_argument('--max-iter',type=int,default=200)
 a=p.parse_args();arr=np.load(a.npz,allow_pickle=False);X=check_X(arr['X'],2);y=arr['y'];K=len(np.unique(y));o=Path(a.outdir);o.mkdir(parents=True,exist_ok=True)
 base=Config(max_iter=a.max_iter);seen=0;h=hashlib.sha256(Path(a.npz).read_bytes()).hexdigest()
 for key,values in GRID.items():
  for v in values:
   if key=='kg' and v>=X.shape[1]:continue
   for seed in parse_seeds(a.seeds):
    c=Config(**{**asdict(base),key:v})
    if c.lambda0<c.lambda_min:continue
    start=time.perf_counter();sol=optimize(X,K,c,seed)
    pred=KMeans(n_clusters=K,init='k-means++',n_init=c.n_init,random_state=seed).fit_predict(sol['cluster_codes'].T)
    row={'dataset':a.dataset,'method':'SWiNMF-R/sensitivity','parameter':key,'parameter_value':v,'seed':seed,'input_sha256':h,
         'iterations':sol['iterations'],'lambda_final':sol['lambda'],'time_sec':time.perf_counter()-start,
         'label_usage':'evaluation only; DO NOT tune from test metrics',**metrics(y,pred)}
    (o/f'{a.dataset}__sensitivity_{key}_{v}_seed_{seed}.json').write_text(json.dumps(row,indent=2));seen+=1
    if a.max_runs and seen>=a.max_runs:break
   if a.max_runs and seen>=a.max_runs:break
  if a.max_runs and seen>=a.max_runs:break
 print('Measured sensitivity runs',seen)

#!/usr/bin/env python3
"""Predeclared controlled variants on identical X: full, graph_off, lambda_fixed,
complement_off and ridge_off. The unsplit condition is supplied by the separate matched-baselines run.
Ridge-off is DIAGNOSTIC because removing eta reintroduces scale degeneracy.
"""
import argparse
from swinmf.model import run_dataset,Config,parse_seeds
from baselines.matched_baselines import run_baselines
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--npz',required=True);p.add_argument('--dataset',required=True)
 p.add_argument('--outdir',default='logs/ablations');p.add_argument('--seeds',default='0-9');p.add_argument('--max-iter',type=int,default=200)
 a=p.parse_args();seed=parse_seeds(a.seeds);cfg=Config(max_iter=a.max_iter)
 r=run_dataset(a.npz,a.dataset,a.outdir,seed,cfg,('graph_off','lambda_fixed','complement_off','ridge_off'))
 print('Completed',len(r),'ablation/comparison runs; ridge_off tests finite iterations only')

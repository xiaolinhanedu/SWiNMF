# SWiNMF-R — Source code and reproducibility workflow

**Status:** Research software implementation and experimentally testable pipeline.
**Not yet a verified six-benchmark reproduction.** See [Release status](RELEASE_STATUS.json).

This repository implements the **revised** regularized Split-Weighted Nonnegative
Matrix Factorization (SWiNMF-R) formulation for single-view clustering. It is
associated with the manuscript *SWiNMF: Split-Weighted Nonnegative Matrix
Factorization for Single-View Image Clustering with Manifold Preservation*.
The optimization objective, fixed hyperparameters and statistical protocol are
not identical to those of the originally submitted paper. Original benchmark
numbers must **not** be carried forward as results of this implementation.

## Directory structure

| Directory | Purpose |
|---|---|
| `swinmf/` | Regularized objective, projected block optimization, sparse graph, clustering metrics, seed-logged main runner |
| `baselines/` | Explicitly defined, same-feature NMF/GNMF/L1-SparseNMF/FeatureWeightedNMF comparisons |
| `ablations/` | Graph, coefficient, ridge and complementary-term controls; sensitivity sweeps |
| `descriptors/` | Image-to-descriptor preprocessing scripts, plus generated data destination |
| `diagnostics/` | Objective convergence and adaptive-coefficient traces |
| `stats/` | Mean, sample SD, initialization CIs and seed-matched exploratory tests |
| `tools/` | Expensive all-six benchmark orchestration with input checks |
| `tests/` | Automated software integrity and mathematical checks |
| `validation/` | **Synthetic only** input generator and small tracked fixture |
| `data/` | Author-provided original images (not included or committed) |
| `logs/`, `figures/` | Output directories (empty on GitHub) |

## Installation and quick verification

From the **repository root** (the directory with `pyproject.toml`):

```bash
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e .
python -m unittest discover -s tests -v
python -m validation.generate_synthetic
python -m swinmf.run_swinmf --npz validation/synthetic_only.npz --dataset SYNTHETIC_ONLY --outdir validation/logs --seeds 0-2 --max-iter 25
python -m baselines.matched_baselines --npz validation/synthetic_only.npz --dataset SYNTHETIC_ONLY --outdir validation/logs --seeds 0-2 --max-iter 25
python -m stats.aggregate_and_test --logs validation/logs --outdir validation/stats
python -m diagnostics.plot_convergence --logs validation/logs --outdir validation/figures
python -m diagnostics.lambda_diagnostics --logs validation/logs --outdir validation/figures
```

Expected outcome: unit tests pass; the smoke workflow writes seed-level JSON,
SWiNMF objective traces, aggregate CSVs and PDF figures in `validation/`.
Short smoke runs may have an optimizer convergence warning: the iteration cap
is deliberately small. **All such scores are synthetic software-test outputs,
not image-benchmark evidence.**

## Mathematical specification

For one normalized image descriptor matrix X, partition its rows by stable
decreasing variance into X₁, X₂. With W₁, W₂, H nonnegative, minimize

```text
F = ||X1-W1 H||_F² / ||X1||_F²
  + lambda ||X2-W2 H||_F² / ||X2||_F²
  + (alpha/n) trace(H L H^T)
  + beta (lambda-lambda0)²
  + (eta/2) (||W1||_F² + ||W2||_F² + ||H||_F²/n).
```

Reconstruction normalizers have a safe positive epsilon lower bound.
The graph is a nonnegative, zero-diagonal kNN affinity symmetrized by the
**arithmetic mean**, with L = D − S. The default sparse kNN search is exact.
Adaptive lambda minimizes its 1D quadratic subproblem by projecting
`lambda0 - E2/(2*beta)` onto `[lambda_min, lambda_max]`; this is **one-way
attenuation**, not unrestricted two-directional adaptation. The strictly positive
ridge penalty fixes the original scale degeneracy. Optimization uses projected
block-gradient steps with sufficient-descent backtracking and an exact lambda
update; empirical objective nonincrease is tested, **not** a proof of global
optimality. Defaults: rho=.5, kg=7, alpha=.1, beta=1, lambda0=1,
lambda_min=.1, lambda_max=1, eta=.001, max_iter=200, tol=1e-5,
K-means++ restarts=20.

## Input format and preprocessing

Saved `.npz` descriptor input requires `X` (nonnegative, shape `features × samples`)
and `y` (one label per sample, for **evaluation only**). Number of clusters `K`
is set to the benchmark's prespecified number of classes, not learned from test
labels. No supervised labels enter graph building, row splitting, factorization
or K-means. See [dataset protocol](docs/EXPERIMENT_PROTOCOL.md) for precisely
what is and is not historically established.

**Raw face/object images**: obtain an authorized ORL, Yale and COIL20 copy and
arrange `data/<dataset>/<class>/<image>`; datasets are **not** included.

```bash
python -m descriptors.make_raw_descriptors --root data --outdir descriptors
```

**Frozen ResNet-50 features**: requires separately installed compatible
`torch` and `torchvision` matched to your CPU/CUDA platform and legitimately
accessible model weights. Downloading dataset files occurs **only** with the
explicit `--download` flag.

```bash
python -m descriptors.make_resnet_descriptors --root data --outdir descriptors --download --device auto
```

Protocol: ORL/Yale/COIL20 raw 32×32 grayscale, flattened and sample-wise L2
normalized; MNIST is replicated into 3 channels for pretrained ResNet-50;
MNIST 60,000 training + 10,000 test, STL10 5,000 labeled training + 8,000
test (excludes 100,000 unlabeled), CIFAR10 50,000 training + 10,000 test.
Frozen `ResNet50_Weights.IMAGENET1K_V2`, its official inference transform,
2048-d pooled descriptors, clamped to nonnegative then L2-normalized. Train
and test are merged **transductively** as an explicit new proposed protocol,
not a verified reconstruction of historical processing.

## Measured six-benchmark evaluation (author must obtain inputs)

For a single dataset:

```bash
python -m swinmf.run_swinmf --npz descriptors/orl.npz --dataset orl --seeds 0-9 --outdir logs
python -m baselines.matched_baselines --npz descriptors/orl.npz --dataset orl --seeds 0-9 --outdir logs
python -m ablations.run_ablations --npz descriptors/orl.npz --dataset orl --seeds 0-9 --outdir logs
python -m ablations.run_sensitivity --npz descriptors/orl.npz --dataset orl --seeds 0-2 --outdir sensitivity_runs
python -m stats.aggregate_and_test --logs logs --outdir stats/out
python -m diagnostics.plot_convergence --logs logs --outdir figures
python -m diagnostics.lambda_diagnostics --logs logs --outdir figures
```

To run the **validated** six-dataset matrix (once all six descriptor files
exist, the hardware can accommodate it, and provenance was checked):

```bash
python -m tools.run_all_benchmarks --descriptors descriptors --logs real_benchmark_logs --seeds 0-9 --max-iter 200 --yes-expensive
```

These commands are **not** executed automatically on publication. For 60–70k
images, exact graph search can be very demanding. Optional `pynndescent` backend
requires `pip install -e '.[approx]'` and `--neighbor-backend pynndescent`; it
is a distinct approximation protocol, must be labeled, and requires empirical
agreement checks. The main runtime includes factorization and 20-restart
K-means, but excludes graph preprocessing and feature extraction (logged
separately where available). The result pipeline archives per-seed method,
version, input hash, configuration and iteration history.

## Statistical interpretation and scientific limitations

- ACC uses Hungarian cluster-label matching; NMI uses arithmetic normalization.
- Report sample SD across seeds and per-dataset paired comparisons matched
  **by seed ID**. Exploratory Wilcoxon comparisons are Holm-adjusted within
  a dataset × metric family.
- Seeds are repeated initialization on **one fixed dataset**, not independent
  biological or visual populations. Initialization confidence intervals are
  descriptive and do not confer cross-dataset inference.
- NMF/GNMF/L1-SparseNMF/fixed-variance FeatureWeightedNMF are explicitly defined
  in source and tested on identical X; the last method is **not** a claimed
  reproduction of an independently published weighted/orthogonal method.
- Deep-clustering methods with learned representations are literature context,
  **not** directly pooled in a fixed-representation leaderboard.
- Parameter sweeps show label-based descriptive evaluations; do **not** choose
  hyperparameters using evaluation labels.

## Cite and archive this software

`CITATION.cff` contains accurate known author and software metadata, **no
invented repository DOI**. The author should review it, select a valid software
license in place of [the licensing notice](LICENSE_SELECTION_REQUIRED.md),
then follow [GitHub + Zenodo instructions](docs/GITHUB_AND_ZENODO.md). Zenodo
requires an enabled repository plus an actual release to issue a DOI.

For journal revision, see [research readiness](docs/REVIEWER_EVIDENCE_CHECKLIST.md).

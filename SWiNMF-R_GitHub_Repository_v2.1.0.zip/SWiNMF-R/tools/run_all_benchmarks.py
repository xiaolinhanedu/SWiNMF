#!/usr/bin/env python3
"""Run verifiable real-data experiments ONLY after all six benchmark NPZs exist.
This does not download data, infer ethics approvals, nor fill missing results.
Outputs logs; may be computationally prohibitive with exact graph search on large n.
"""
import argparse,sys,hashlib,json
from pathlib import Path
import numpy as np
from swinmf.model import Config,run_dataset,parse_seeds
from baselines.matched_baselines import run_baselines
from stats.aggregate_and_test import summarize

SPEC={'orl':(400,1024,40),'yale':(165,1024,15),'coil20':(1440,1024,20),
      'mnist':(70000,2048,10),'stl10':(13000,2048,10),'cifar10':(60000,2048,10)}
def check(path,name):
    with np.load(path,allow_pickle=False) as f:X=f['X'];y=f['y']
    n,d,k=SPEC[name]
    if X.shape!=(d,n):raise ValueError(f'{name}: expected (d,n)=({d},{n}), got {X.shape}')
    if len(y)!=n or len(np.unique(y))!=k:raise ValueError(f'{name}: labels inconsistent with declared benchmark')
    if np.any(X<0) or not np.isfinite(X).all():raise ValueError(f'{name}: expected finite nonnegative descriptors')
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--descriptors',default='descriptors');p.add_argument('--logs',default='real_benchmark_logs')
    p.add_argument('--seeds',default='0-9');p.add_argument('--max-iter',type=int,default=200)
    p.add_argument('--neighbor-backend',choices=['exact','pynndescent'],default='exact')
    p.add_argument('--datasets',default='orl,yale,coil20,mnist,stl10,cifar10')
    p.add_argument('--yes-expensive',action='store_true',help='Confirm full 6-dataset job can use hours or days of computation')
    a=p.parse_args();names=a.datasets.split(',');missing=[x for x in names if not (Path(a.descriptors)/(x+'.npz')).exists()]
    if missing:raise SystemExit('Missing measured benchmark descriptors: '+','.join(missing)+'. Generate them first; see README.')
    if not a.yes_expensive:raise SystemExit('No runs started; include --yes-expensive after reviewing disk/memory and dataset licenses.')
    out=Path(a.logs);out.mkdir(parents=True,exist_ok=True)
    seeds=parse_seeds(a.seeds);cfg=Config(max_iter=a.max_iter,neighbor_backend=a.neighbor_backend)
    manifest=[]
    for name in names:
        if name not in SPEC:raise ValueError('unknown dataset '+name)
        pth=Path(a.descriptors)/(name+'.npz');h=check(pth,name)
        manifest.append({'dataset':name,'npz':str(pth.resolve()),'sha256':h,'n':SPEC[name][0]})
        run_dataset(pth,name,out,seeds,cfg,('full','graph_off','lambda_fixed','complement_off','ridge_off'))
        run_baselines(pth,name,out,seeds,max_iter=a.max_iter,backend=a.neighbor_backend)
        (out/'input_manifest.json').write_text(json.dumps(manifest,indent=2))
    print('Completed',len(names),'measured benchmark datasets')
    print('Summary:',summarize(out,out/'summary'))

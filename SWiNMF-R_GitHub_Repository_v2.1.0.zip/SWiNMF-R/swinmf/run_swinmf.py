"""CLI wrapper: python -m swinmf.run_swinmf ... from repository root."""
from .model import main
if __name__=='__main__':main()

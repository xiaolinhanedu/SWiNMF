#!/usr/bin/env python3
"""SWiNMF-R v2: regularized single-matrix split NMF (new objective, not historical scores).

F = ||X1-W1 H||²/s1 + lam*||X2-W2 H||²/s2
    + alpha/n tr(H L H.T) + beta*(lam-lambda0)²
    + eta/2*(||W1||² + ||W2||² + ||H||²/n).
All factors nonnegative; lam in [lambda_min,lambda_max].
Projected block gradients with backtracking ensure non-increase of computed objective.
This is a monotone-iterate implementation, NOT a global convergence-rate proof.
"""
import csv, hashlib, json, os, platform, sys, time, argparse
from pathlib import Path
from dataclasses import dataclass, asdict
import numpy as np
from scipy import sparse
from scipy.optimize import linear_sum_assignment
from sklearn.cluster import KMeans
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score, f1_score
EPS=1e-12
__version__='SWiNMF-R-v2.1.0'

@dataclass
class Config:
    rho:float=.5
    kg:int=7
    alpha:float=.1
    beta:float=1.
    lambda0:float=1.
    lambda_min:float=.1
    lambda_max:float=1.
    eta:float=.001
    max_iter:int=200
    tol:float=1e-5
    graph_sym:str='mean'
    n_init:int=20
    neighbor_backend:str='exact' # 'pynndescent' explicitly selected, never silent approximation

def validate_config(cfg,X):
    n=X.shape[1]; d=X.shape[0]
    if not 0<cfg.rho<1 or not 1<=int(np.ceil(cfg.rho*d))<d: raise ValueError('rho must produce nonempty partitions')
    if not isinstance(cfg.kg,int) or not 1<=cfg.kg<n: raise ValueError('kg must satisfy 1 <= kg < sample count')
    if cfg.alpha<0 or cfg.eta<0 or cfg.beta<=0:raise ValueError('alpha/eta >= 0 and beta > 0 required')
    if not 0<=cfg.lambda_min<=cfg.lambda0<=cfg.lambda_max: raise ValueError('Require 0 <= lambda_min <= lambda0 <= lambda_max')
    if cfg.max_iter<1 or cfg.n_init<1 or not 0<cfg.tol<1:raise ValueError('iteration and tolerance settings invalid')
    if cfg.graph_sym not in ('mean','max'):raise ValueError('graph_sym must be mean or max')
    if cfg.neighbor_backend not in ('exact','pynndescent'):raise ValueError('neighbor_backend exact/pynndescent only')

def check_X(X,K):
    X=np.asarray(X,dtype=np.float64)
    if X.ndim!=2 or X.shape[0]<2 or X.shape[1]<3: raise ValueError('X must be d x n, d>=2 and n>=3')
    if not np.isfinite(X).all() or np.min(X)<0:raise ValueError('X finite, nonnegative required')
    if not 1<=K<=X.shape[1]:raise ValueError('K out of range')
    return X

def normalize(X):
    return X/np.maximum(np.linalg.norm(X,axis=0,keepdims=True),EPS)

def split(X,rho):
    if not 0<rho<1:raise ValueError('rho must be in (0,1)')
    d=X.shape[0]; d1=int(np.ceil(rho*d))
    if not 1<=d1<d:raise ValueError('empty feature partition')
    order=np.lexsort((np.arange(d),-np.var(X,axis=1)))
    return X[order[:d1]],X[order[d1:]],order

def graph(X,kg,sym='mean',backend='exact'):
    n=X.shape[1]
    if not 1<=kg<n:raise ValueError('kg out of range')
    if sym not in ('mean','max'):raise ValueError('unknown graph symmetrization')
    if backend=='exact':
        # query k+1; if self omitted among tied duplicate observations, fallback to per-point exact k+2 etc
        nn=NearestNeighbors(n_neighbors=min(n,kg+1),metric='euclidean').fit(X.T)
        dist,idx=nn.kneighbors(X.T)
    elif backend=='pynndescent':
        try:from pynndescent import NNDescent
        except ImportError as e:raise ImportError('Install pynndescent explicitly to use neighbor_backend=pynndescent') from e
        index=NNDescent(X.T,n_neighbors=min(n,max(kg+20,15)),random_state=0,metric='euclidean')
        idx,dist=index.query(X.T,k=min(n,kg+10))
    else:raise ValueError('Unknown neighbor backend')
    rows=[]; cols=[]; dd=[]; sig=[]
    for i in range(n):
        found=[(float(v),int(j)) for v,j in zip(dist[i],idx[i]) if int(j)!=i]
        if len(found)<kg:
            if backend=='exact':
                dv,iv=nn.kneighbors(X[:,i][None,:],n_neighbors=n)
                found=[(float(v),int(j)) for v,j in zip(dv[0],iv[0]) if int(j)!=i]
            else:
                raise ValueError('Approximate neighbor search did not return enough non-self neighbors; increase search capacity')
        found=sorted(found,key=lambda p:(p[0],p[1]))[:kg]
        if len(found)!=kg:raise ValueError('insufficient neighbors')
        sig.append(max(found[-1][0],1e-8))
        for distance,j in found:rows.append(i);cols.append(j);dd.append(distance)
    rows=np.asarray(rows);cols=np.asarray(cols);sig=np.asarray(sig)
    weights=np.exp(-np.asarray(dd)**2/(2*sig[rows]*sig[cols]))
    A=sparse.csr_matrix((weights,(rows,cols)),shape=(n,n))
    S=(A+A.T)*.5 if sym=='mean' else A.maximum(A.T)
    S=S.tocsr();S.setdiag(0);S.eliminate_zeros()
    D=sparse.diags(np.asarray(S.sum(axis=1)).ravel(),format='csr')
    L=(D-S).tocsr()
    return S,D,L

def terms(X1,X2,W1,W2,H,lam,L,cfg,s1,s2):
    n=H.shape[1]
    E1=float(np.sum((X1-W1@H)**2)/s1)
    E2=float(np.sum((X2-W2@H)**2)/s2)
    manifold=float(cfg.alpha/n*np.sum((H@L)*H))
    ridge=float(cfg.eta/2*(np.sum(W1*W1)+np.sum(W2*W2)+np.sum(H*H)/n))
    prior=float(cfg.beta*(lam-cfg.lambda0)**2)
    return {'E1':E1,'E2':E2,'manifold':manifold,'ridge':ridge,'prior':prior,'objective':E1+lam*E2+manifold+ridge+prior}

def gradients(X1,X2,W1,W2,H,lam,L,cfg,s1,s2):
    n=H.shape[1];R1=W1@H-X1;R2=W2@H-X2
    g1=2*R1@H.T/s1+cfg.eta*W1
    g2=2*lam*R2@H.T/s2+cfg.eta*W2
    gH=2*W1.T@R1/s1+2*lam*W2.T@R2/s2+2*cfg.alpha/n*(H@L)+cfg.eta/n*H
    g_lambda=np.sum(R2*R2)/s2+2*cfg.beta*(lam-cfg.lambda0)
    return g1,g2,gH,g_lambda

def _pg_step(Z,g,f,current,step0):
    step=max(float(step0),1e-14)
    for _ in range(40):
        cand=np.maximum(0,Z-step*g)
        value=f(cand)
        # Squared projected displacement ensures a genuine descent if iterates move.
        needed=1e-6*np.sum((cand-Z)**2)/step
        if np.isfinite(value) and value <= current-needed+1e-12:
            return cand,float(value)
        step*=.5
    return Z,current

def optimize(X,K,cfg=None,seed=0,variant='full',precomputed_graph=None):
    cfg=cfg or Config(); X=normalize(check_X(X,K));validate_config(cfg,X)
    n=X.shape[1];X1,X2,order=split(X,cfg.rho)
    S,D,L=precomputed_graph if precomputed_graph is not None else graph(X,cfg.kg,cfg.graph_sym,cfg.neighbor_backend)
    s1=max(np.sum(X1*X1),EPS);s2=max(np.sum(X2*X2),EPS)
    rng=np.random.default_rng(seed)
    W1=rng.uniform(.01,.05,size=(X1.shape[0],K))
    W2=rng.uniform(.01,.05,size=(X2.shape[0],K))
    H=rng.uniform(.05,.2,size=(K,n))
    lam=cfg.lambda0
    run=Config(**asdict(cfg))
    if variant=='graph_off':run.alpha=0.
    elif variant=='ridge_off':run.eta=0.
    elif variant=='complement_off':run.lambda0=0.;run.lambda_min=0.;run.lambda_max=0.;lam=0.
    elif variant not in ('full','lambda_fixed'):raise ValueError('unknown variant '+variant)
    def obj(w1=None,w2=None,h=None,l=None):
        return terms(X1,X2,W1 if w1 is None else w1,W2 if w2 is None else w2,H if h is None else h,lam if l is None else l,L,run,s1,s2)['objective']
    trace=[dict(iteration=0,lambda_value=lam,**terms(X1,X2,W1,W2,H,lam,L,run,s1,s2))]
    stop='max_iter'
    for it in range(1,run.max_iter+1):
        g1,g2,_,_=gradients(X1,X2,W1,W2,H,lam,L,run,s1,s2)
        lip=2*np.linalg.norm(H@H.T,2)
        W1,_=_pg_step(W1,g1,lambda w:obj(w1=w),obj(),1/(lip/s1+run.eta+EPS))
        _,g2,_,_=gradients(X1,X2,W1,W2,H,lam,L,run,s1,s2)
        W2,_=_pg_step(W2,g2,lambda w:obj(w2=w),obj(),1/(lam*lip/s2+run.eta+EPS))
        _,_,gH,_=gradients(X1,X2,W1,W2,H,lam,L,run,s1,s2)
        lop=2*float(np.max(D.diagonal()))
        lipH=2*np.linalg.norm(W1.T@W1,2)/s1+2*lam*np.linalg.norm(W2.T@W2,2)/s2+2*run.alpha*lop/n+run.eta/n
        H,_=_pg_step(H,gH,lambda h:obj(h=h),obj(),1/(lipH+EPS))
        if variant!='lambda_fixed' and variant!='complement_off':
            e2=np.sum((X2-W2@H)**2)/s2
            lam=float(np.clip(run.lambda0-e2/(2*run.beta),run.lambda_min,run.lambda_max))
        entry=dict(iteration=it,lambda_value=lam,**terms(X1,X2,W1,W2,H,lam,L,run,s1,s2))
        trace.append(entry)
        if abs(trace[-2]['objective']-entry['objective'])/max(abs(trace[-2]['objective']),EPS)<run.tol:
            stop='relative_objective_change';break
    return {'W1':W1,'W2':W2,'H':H,'cluster_codes':normalize(H),'lambda':lam,'trace':trace,
            'iterations':len(trace)-1,'stop_reason':stop,'order':order,'cfg':run}

def metrics(y,p):
    y=np.asarray(y);p=np.asarray(p)
    if y.shape!=p.shape or y.ndim!=1:raise ValueError('labels must be vectors of same shape')
    classes,yi=np.unique(y,return_inverse=True)
    clusters,pi=np.unique(p,return_inverse=True)
    tab=np.zeros((len(clusters),len(classes)),dtype=np.int64)
    np.add.at(tab,(pi,yi),1)
    r,c=linear_sum_assignment(-tab)
    mapper=dict(zip(r,c));mapped=np.array([mapper.get(q,-1) for q in pi])
    return {'ACC':float(np.mean(mapped==yi)), 'NMI':float(normalized_mutual_info_score(y,p,average_method='arithmetic')),
            'ARI':float(adjusted_rand_score(y,p)), 'macroF1':float(f1_score(yi,mapped,labels=range(len(classes)),average='macro',zero_division=0))}

def parse_seeds(s):
    out=[]
    for token in s.split(','):
        if '-' in token:
            u,v=map(int,token.split('-'))
            if v<u:raise ValueError('descending seed range')
            out.extend(range(u,v+1))
        else:out.append(int(token))
    if len(set(out))!=len(out):raise ValueError('duplicate seed values')
    return out

def run_dataset(npz,dataset,outdir,seeds,cfg,variants=('full',)):
    with np.load(npz,allow_pickle=False) as arr:X=arr['X'];y=arr['y']
    K=len(np.unique(y));X=check_X(X,K);validate_config(cfg,X)
    if len(y)!=X.shape[1]:raise ValueError('label length must match X columns')
    out=Path(outdir);out.mkdir(parents=True,exist_ok=True)
    src_hash=hashlib.sha256(Path(npz).read_bytes()).hexdigest()
    tgraph=time.perf_counter();g=graph(normalize(X),cfg.kg,cfg.graph_sym,cfg.neighbor_backend);graphtime=time.perf_counter()-tgraph
    records=[]
    for variant in variants:
        for seed in seeds:
            start=time.perf_counter();sol=optimize(X,K,cfg,seed,variant,precomputed_graph=g)
            pred=KMeans(n_clusters=K,init='k-means++',n_init=cfg.n_init,random_state=seed).fit_predict(sol['cluster_codes'].T)
            dur=time.perf_counter()-start
            name=f'{dataset}__SWiNMF-R-{variant}__seed_{seed:02d}'
            row={'dataset':dataset,'method':'SWiNMF-R/'+variant,'seed':seed,'representation':'supplied descriptor NPZ',
                 'input_sha256':src_hash,'algorithm_version':__version__,'config':asdict(cfg), 'effective_config':asdict(sol['cfg']),
                 'iterations':sol['iterations'],'stopping':sol['stop_reason'],'time_sec':dur,'graph_precompute_sec':graphtime,
                 'runtime_definition':'optimization and k-means; graph cost recorded separately; feature extraction excluded',
                 'lambda_final':sol['lambda'],'objective_final':sol['trace'][-1]['objective'],
                 'environment':{'python':platform.python_version(),'numpy':np.__version__,'machine':platform.platform()},
                 **metrics(y,pred)}
            (out/(name+'.json')).write_text(json.dumps(row,indent=2))
            with (out/(name+'_trace.csv')).open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=sol['trace'][0].keys());w.writeheader();w.writerows(sol['trace'])
            records.append(row)
    return records

def main():
    a=argparse.ArgumentParser();a.add_argument('--npz',required=True);a.add_argument('--dataset',required=True)
    a.add_argument('--outdir',default='logs');a.add_argument('--seeds',default='0-9')
    a.add_argument('--variants',default='full');a.add_argument('--max-iter',type=int,default=200)
    a.add_argument('--neighbor-backend',choices=['exact','pynndescent'],default='exact')
    args=a.parse_args()
    cfg=Config(max_iter=args.max_iter,neighbor_backend=args.neighbor_backend)
    r=run_dataset(args.npz,args.dataset,args.outdir,parse_seeds(args.seeds),cfg,args.variants.split(','))
    print('Measured runs:',len(r))
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Explicit same-descriptor baselines; not reproductions of unnamed published pipelines.
NMF: sklearn coordinate descent, objective ||X-WH||²/2.
GNMF: nonnegative projected-gradient, ||X-WH||²/s + alpha/n tr(H L H.T) + eta/2(||W||²+||H||²/n).
SparseNMF: same as regularized NMF plus gamma*||H||_1/n; not Hoyer projection.
FeatureWeightedNMF: q_i=(variance_i+eps) / mean(variance+eps),
 J=||diag(sqrt(q)) (X-WH)||²/s + eta/2(||W||²+||H||²/n),
 with q fixed *before factorization* and no ground-truth labels.
"""
import argparse, hashlib, json, platform, time
from pathlib import Path
import numpy as np
from sklearn.decomposition import NMF
from sklearn.cluster import KMeans
from swinmf.model import Config,check_X,normalize,graph,metrics,parse_seeds,_pg_step,EPS

def custom_nmf(X,K,method='GNMF',seed=0,T=200,tol=1e-5,alpha=.1,eta=.001,gamma=.005,kg=7,backend='exact',graph_precomputed=None):
    d,n=X.shape
    q=np.ones((d,1))
    if method=='FeatureWeightedNMF':
        v=np.var(X,axis=1)[:,None];q=(v+1e-5)/np.mean(v+1e-5)
    S,D,L=(graph_precomputed if graph_precomputed is not None else graph(X,kg,backend=backend)) if method=='GNMF' else (None,None,None)
    rng=np.random.default_rng(seed);W=rng.uniform(.01,.05,(d,K));H=rng.uniform(.05,.2,(K,n))
    s=max(float(np.sum(q*X*X)),EPS)
    graph_coeff=alpha if method=='GNMF' else 0.
    sparsity=gamma if method=='SparseNMF' else 0.
    def fun(w,h):
        resid=X-w@h
        return float(np.sum(q*resid*resid)/s+graph_coeff/n*np.sum((h@L)*h) if L is not None else np.sum(q*resid*resid)/s) + eta/2*(np.sum(w*w)+np.sum(h*h)/n)+sparsity/n*np.sum(h)
    prev=fun(W,H)
    for it in range(1,T+1):
        R=W@H-X
        gW=2*(q*R)@H.T/s+eta*W
        lipW=2*np.max(q)*np.linalg.norm(H@H.T,2)/s+eta
        W,_=_pg_step(W,gW,lambda w:fun(w,H),fun(W,H),1/(lipW+EPS))
        R=W@H-X
        gH=2*W.T@(q*R)/s+eta/n*H+sparsity/n
        lipH=2*np.max(q)*np.linalg.norm(W.T@W,2)/s+eta/n
        if L is not None:
            gH+=2*graph_coeff/n*(H@L)
            lipH+=4*graph_coeff/n*np.max(D.diagonal())
        H,_=_pg_step(H,gH,lambda h:fun(W,h),fun(W,H),1/(lipH+EPS))
        curr=fun(W,H)
        if (prev-curr)/max(abs(prev),EPS)<tol:break
        prev=curr
    return H,it,curr

def run_baselines(npz,dataset,outdir,seeds,methods=('NMF','GNMF','SparseNMF','FeatureWeightedNMF'),max_iter=200,backend='exact'):
    with np.load(npz,allow_pickle=False) as a:X=check_X(a['X'],2);y=a['y']
    if len(y)!=X.shape[1]:raise ValueError('X / y size mismatch')
    K=len(np.unique(y));X=normalize(X)
    filehash=hashlib.sha256(Path(npz).read_bytes()).hexdigest()
    out=Path(outdir);out.mkdir(parents=True,exist_ok=True)
    g=None;gt=0.
    if 'GNMF' in methods:
        t=time.perf_counter();g=graph(X,7,backend=backend);gt=time.perf_counter()-t
    rows=[]
    for method in methods:
        if method not in ('NMF','GNMF','SparseNMF','FeatureWeightedNMF'):raise ValueError('Unknown baseline')
        for seed in seeds:
            start=time.perf_counter()
            if method=='NMF':
                m=NMF(n_components=K,init='random',solver='cd',max_iter=max_iter,random_state=seed,tol=1e-5)
                H=m.fit_transform(X.T).T;n_iter=int(m.n_iter_);objective=float(m.reconstruction_err_**2)
            else:
                H,n_iter,objective=custom_nmf(X,K,method,seed,T=max_iter,backend=backend,graph_precomputed=g)
            code=normalize(H)
            pred=KMeans(n_clusters=K,n_init=20,random_state=seed,init='k-means++').fit_predict(code.T)
            runtime=time.perf_counter()-start
            row={'dataset':dataset,'method':method,'seed':seed,'ACC':None,'input_sha256':filehash,
                 'representation':'same supplied descriptor NPZ','algorithm_version':'matched_baselines_v2.1.0',
                 'iterations':n_iter,'objective_final':objective,'time_sec':runtime,'graph_precompute_sec':gt if method=='GNMF' else 0,
                 'runtime_definition':'factorization plus 20-restart k-means; feature extraction and graph cost separate',
                 'environment':{'python':platform.python_version(),'numpy':np.__version__},
                 'config':{'max_iter':max_iter,'kmeans_n_init':20,'graph_backend':backend,'eta':.001,'alpha_gnmf':.1,'gamma_sparse':.005,
                           'feature_weights':'fixed variance+1e-5 normalized to average 1' if method=='FeatureWeightedNMF' else 'none'},
                 **metrics(y,pred)}
            (out/f'{dataset}__{method}__seed_{seed:02d}.json').write_text(json.dumps(row,indent=2))
            rows.append(row)
    return rows
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--npz',required=True);p.add_argument('--dataset',required=True)
    p.add_argument('--outdir',default='logs');p.add_argument('--seeds',default='0-9');p.add_argument('--max-iter',type=int,default=200)
    p.add_argument('--neighbor-backend',choices=['exact','pynndescent'],default='exact')
    a=p.parse_args();r=run_baselines(a.npz,a.dataset,a.outdir,parse_seeds(a.seeds),max_iter=a.max_iter,backend=a.neighbor_backend)
    print('Completed',len(r),'matched baseline runs')

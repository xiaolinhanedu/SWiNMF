#!/usr/bin/env python3
"""Generate a transparent fixed 3-class SYNTHETIC test fixture; never a real benchmark."""
from pathlib import Path
import numpy as np
rng_basis=np.random.default_rng(24)
K=3;n=60;d=16
basis=rng_basis.gamma(2.,.8,(d,K))
labels=np.repeat(np.array([12,58,99]),n//K)
H=np.zeros((K,n));H[np.repeat(np.arange(K),n//K),np.arange(n)]=1.
rng_noise=np.random.default_rng(48)
X=np.maximum(basis@H+1.6*rng_noise.normal(size=(d,n)),0)
file=Path(__file__).parent/'synthetic_only.npz'
np.savez_compressed(file,X=X,y=labels)
print('Generated',file,'shape',X.shape,'seed_basis',24,'seed_noise',48,'noise_sigma',1.6)
